# Commands

Define comandos cortos que activan agentes, contexto y forma de trabajo
sin necesidad de describir todo manualmente.

Cada comando:

- selecciona agente principal
- define alcance
- aplica reglas de memory + constraints
- estandariza la salida

---

## audit repo

Objetivo: Auditar el sistema completo con cambios seguros.

Agente: auditor

Comportamiento:

- analizar código real (no README)
- reconstruir flujo actual
- detectar problemas reales
- proponer cambios mínimos
- NO ejecutar sin confirmación si hay riesgo

Output esperado:

1. diagnóstico
2. problemas
3. riesgos
4. cambios propuestos
5. archivos afectados

---

## review security

Objetivo: Detectar riesgos reales de seguridad.

Agente: seguridad

Alcance:

- auth / authz
- tenant isolation
- validación
- endpoints públicos
- exposición de datos

Output esperado:

1. superficie analizada
2. hallazgos verificados
3. hallazgos probables
4. riesgos multi-tenant
5. limitaciones

---

## optimize booking

Objetivo: Mejorar flujo de reservas sin romper lógica.

Agente: flujo

Comportamiento:

- mapear flujo end-to-end
- detectar fricciones
- validar contratos
- proponer mejoras mínimas

Output esperado:

1. flujo actual
2. fricciones
3. riesgos
4. mejoras propuestas
5. impacto

---

## improve ux

Objetivo: Mejorar claridad visual y experiencia.

Agente: ux

Restricción:

- NO tocar backend
- NO tocar contratos

Output esperado:

1. diagnóstico UX
2. problemas
3. cambios propuestos
4. archivos

---

## safe refactor

Objetivo: Refactor controlado sin romper el sistema.

Agente: auditor

Reglas:

- cambios mínimos
- mantener contratos
- validar build

---

## check consistency

Objetivo: Detectar inconsistencias entre capas.

Agente: auditor + flujo

Comportamiento:

- comparar frontend vs backend
- validar naming
- detectar duplicaciones
- validar contratos

---

## debug issue

Objetivo: Diagnosticar bug sin romper nada.

Agente: auditor

Output esperado:

- causa probable
- archivos involucrados
- solución mínima

---

## validate flow

Objetivo: Validar que flujo funciona correctamente.

Agente: flujo

Output:

- pasos reales
- validaciones
- inconsistencias

---

## pre-change check

Objetivo: Evaluar impacto antes de modificar.

Agente: orquestador + auditor

Output:

- impacto
- riesgos
- archivos afectados
- nivel de seguridad

---

## apply change

Objetivo: Ejecutar cambio validado.

Agente: dependiente del contexto

Reglas:

- respetar memory
- respetar contratos
- validar build
- no tocar fuera de alcance

---

## Reglas globales de comandos

- siempre usar memory.md y memory_state.json
- no redefinir arquitectura existente
- no romper contratos sin advertir
- priorizar cambios mínimos
- detenerse ante conflictos

---

## Uso

Ejemplo:

audit repo
review security
optimize booking
improve ux

o

Task: optimize booking
