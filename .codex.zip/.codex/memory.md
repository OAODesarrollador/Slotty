# Sistema de Memoria

## Propósito

Mantener consistencia entre ejecuciones, preservando decisiones de arquitectura,
reglas de negocio y flujos validados.

Esta memoria evita:

- romper funcionalidades ya estables
- inconsistencias entre ejecuciones
- reintroducir problemas ya resueltos

---

## 1. Qué se debe recordar (Memoria persistente)

### Arquitectura

- Estrategia multitenant (basada en subdominios)
- Uso de tenant_id como aislamiento lógico
- Estructura general: frontend → backend → base de datos
- Resolución de dominio + comportamiento fallback

### Sistema de reservas

- Definición del flujo de reserva (pasos, orden, responsabilidades)
- Contrato de disponibilidad (inputs, outputs, reglas)
- Reglas de creación de turnos
- Lógica de prevención de conflictos

### Pagos

- Estados válidos de pago
- Relación entre appointment y payment
- Reglas de expiración y verificación

### Naming y contratos

- Estructura de endpoints
- Convenciones de nombres (tenant, booking, queue, availability)
- Contratos de datos entre frontend y backend

---

## 2. Memoria de corto plazo (contexto de sesión)

Se debe almacenar temporalmente:

- objetivo actual
- archivos que se están modificando
- decisiones recientes
- problemas detectados no resueltos

No debe persistir fuera de la tarea actual.

---

## 3. Reglas de memoria

- No sobrescribir decisiones de arquitectura sin instrucción explícita
- No introducir nuevos patrones si ya existe uno válido
- Priorizar consistencia sobre mejoras dudosas
- Si hay conflicto con decisiones previas:
  → detener ejecución y advertir

---

## 4. Relación con los skills

La memoria NO reemplaza a los skills.

Funciona como contexto:

- auditor → respeta decisiones de arquitectura existentes
- seguridad → usa memoria para validar aislamiento de tenants
- flujo → reutiliza flujo existente antes de proponer cambios
- ux → no debe romper flujos definidos

La memoria aporta CONTEXTO.
Los skills ejecutan.

---

## 5. Aprendizaje a partir de ejecución

Después de una tarea, guardar solo si es relevante:

- decisiones de arquitectura
- cambios confirmados de flujo
- mejoras validadas
- trade-offs importantes

No guardar:

- ideas no implementadas
- debugging temporal
- cambios incompletos

---

## 6. Detección de conflictos

Antes de ejecutar:

Verificar si el cambio afecta:

- flujo de reservas
- aislamiento multitenant
- contratos API

Si afecta:
→ comparar con memoria

Si hay inconsistencia:
→ advertir antes de continuar

---

## 7. Comportamiento de lectura

Antes de empezar cualquier tarea:

1. cargar decisiones de arquitectura
2. cargar flujo de reservas
3. cargar contratos críticos
4. verificar conflictos

Nunca ejecutar sin esto.

---

## 8. Prioridades

1. integridad del sistema
2. coherencia del flujo
3. aislamiento de tenants
4. estabilidad de contratos
5. performance
6. UX

---

## 9. Qué NO recordar

- cambios visuales menores
- ajustes estéticos
- logs temporales
- refactors experimentales

---

## 10. Objetivo

Permitir que el sistema evolucione de forma coherente,
evitando comportamientos inconsistentes entre ejecuciones.
