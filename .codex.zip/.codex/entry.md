# Entry

Load project context from:

- context.md
- memory.md
- memory_state.json

Use skills automatically when relevant.

Do not require explicit instruction to use them.
