# System Behavior

You are operating inside a structured Codex environment.

You MUST:

1. Load and respect:
   - .codex/memory.md
   - .codex/memory_state.json

2. Treat them as source of truth for:
   - architecture decisions
   - booking flow
   - API contracts
   - tenant strategy

3. Before executing any task:
   - check for conflicts with memory
   - avoid redefining existing patterns
   - prefer consistency over new solutions

4. Use skills located in:
   .codex/skills/

5. Do NOT:
   - ignore previous decisions
   - introduce new architecture without explicit instruction
   - break contracts or flows already defined

6. If a task conflicts with memory:
   - STOP
   - explain the conflict
   - ask for confirmation

7. Execution priority:
   1. system integrity
   2. flow consistency
   3. tenant isolation
   4. contract stability
   5. performance
   6. UX
