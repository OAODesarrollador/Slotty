# Default Context

This project uses a structured Codex system.

Always:

- Load and respect:
  - .codex/memory.md
  - .codex/memory_state.json

- Use skills from:
  - .codex/skills/

- Treat memory as source of truth for:
  - architecture
  - booking flow
  - API contracts
  - tenant system

Before executing:

1. Check if the task affects:
   - booking flow
   - tenant logic
   - API contracts
   - payments

2. If yes:
   - validate against memory
   - detect conflicts

Rules:

- Do not redefine existing patterns
- Do not break flows or contracts
- Prefer consistency over new solutions

If conflict exists:
→ STOP and explain
