#!/usr/bin/env bash
set -e

echo "===> Iniciando verificación del proyecto"

if [ ! -f package.json ]; then
  echo "No se encontró package.json en la raíz del proyecto"
  exit 1
fi

echo "===> package.json encontrado"

if npm run | grep -q "lint"; then
  echo "===> Ejecutando lint"
  npm run lint
else
  echo "===> No existe script lint, se omite"
fi

if npm run | grep -q "build"; then
  echo "===> Ejecutando build"
  npm run build
else
  echo "===> No existe script build"
  exit 1
fi

echo "===> Verificación finalizada correctamente"